let hs = document.getElementById('hs')
let As = document.getElementById('As')

let nn = 0
let vount = 0
let count = 0

function h1 () {
    count += 1
    hs.textContent = count
}
function h2 () {
    count += 2
    hs.textContent = count
}
function h3 () {
    count += 3
    hs.textContent = count
}
function A1 () {
    vount += 1
    As.textContent = vount
}
function A2 () {
    vount += 2
    As.textContent = vount
}
function A3 () {
    vount += 3
    As.textContent = vount
}
